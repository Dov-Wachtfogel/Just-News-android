[![Ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/tsurdan)

# Just News Firefox mobile

**Just News mobile** is a Firefox mobile version of [Just News](https://github.com/tsurdan/Just-News) by Tzur Danino, that automatically replaces misleading or clickbait news headlines with clear, factual, and objective alternatives. It enhances your browsing experience by letting you know the essence of an article—without needing to click.

---
<img width="1280" height="800" alt="new-fox" src="https://github.com/user-attachments/assets/83dfcf19-a16f-4ab6-8617-f23969abd2a9" />


## 🧠 How It Works

- Scans the page for visible news headlines.
- Extracts the full article content for each headline.
- Uses **llama AI via Groq API** to generate a new, informative title.
- Replaces the original headline directly on the page, in real time.

---

## 🔑 Setup Instructions

1. Download the extention from firefox add-on sore
2. Enter to your favorite news website
3. Click on the Just-News extention icon (at options->extensions)
4. Follow the guide in the extension popup to generate and add your **Groq API key**.
5. Done. No more clickbait headlines.

---

## 📋 Features

### Free Version
- Clean, informative, non-clickbait headlines
- Multi-language support  
- Lightweight and fast
- Daily usage limit

### Premium Version
- Unlimited daily usage
- Multiple rewriting modes (Cynic, Optimist, Conspirator)
- Custom prompt modes
- Summarization on hover

---

## 🔐 Privacy Policy

Just News is designed with privacy in mind:

- No tracking
- No ads
- No personal data collection
- Article content is sent only to selected LLM API for headline rewriting
- Your API key and premium status are stored **only in your browser's local storage**
- Usage counters for free tier limits are tracked locally only

For more details check the `privacy policy.md` file


---
## 🤝 Contributing

Want to improve or extend the extension? Contributions are welcome!
You can find bugs or feature suggestions in the repo issues

1. Fork this repository
2. Create a new branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m "Add my feature"`
4. Push to your fork: `git push origin feature/my-feature`
5. Open a Pull Request

Please open issues for bugs or feature suggestions. Let's make the news readable again—together!

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
